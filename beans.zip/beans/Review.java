package com.capgemini.bookstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BookStore_Review")
public class Review {

	@Id
	@GeneratedValue
	private int id;
	private String bookTitle;
	private double rating;
	private String customerName;
	private String headLine;
	private String comments;
	private Date reviewDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getHeadLine() {
		return headLine;
	}
	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}
	public String getComment() {
		return comments;
	}
	public void setComment(String comment) {
		this.comments = comment;
	}
	public Date getDate() {
		return reviewDate;
	}
	public void setDate(Date date) {
		this.reviewDate = date;
	}
	public Review(int id, String bookTitle, double  rating, String customerName, String headLine, String comment,
			Date date) {
		super();
		this.id = id;
		this.bookTitle = bookTitle;
		this.rating = rating;
		this.customerName = customerName;
		this.headLine = headLine;
		this.comments = comment;
		this.reviewDate = date;
	}
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Review [id=" + id + ", bookTitle=" + bookTitle + ", rating=" + rating + ", customerName=" + customerName
				+ ", headLine=" + headLine + ", comment=" + comments + ", date=" + reviewDate + "]";
	}
	
	
}
