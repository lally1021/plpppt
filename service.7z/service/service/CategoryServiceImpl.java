package com.capgemini.category.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.category.bean.Category;
import com.capgemini.category.dao.CategoryRepository;
@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
    private CategoryRepository catgdao;
	@Override
	public List<Category> getAllCategories() {
		
		return catgdao.findAll();
	}

	@Override
	public List<Category> addCategory(Category category) {
		catgdao.save(category);
		return getAllCategories();
	}

	@Override
	public List<Category> updateCategory(int id,Category category) {
		if(catgdao.existsById(id)) {
		catgdao.save(category);
		}
		return getAllCategories();
		
	}

	@Override
	public List<Category> deleteCategory(int id) {
		catgdao.deleteById(id);
		return getAllCategories();
	}

	@Override
	public Category getByid(int id) {
		// TODO Auto-generated method stub
		return catgdao.findById(id).get();
	}

}
