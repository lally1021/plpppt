package com.capgemini.category.service;

import java.util.List;

import com.capgemini.category.bean.Category;

public interface CategoryService {
    List<Category> getAllCategories();
    List<Category> addCategory(Category category);
    List<Category> updateCategory(int id,Category category);
    List<Category> deleteCategory(int id);
	Category getByid(int id);
}
