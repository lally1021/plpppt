import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/bean/user';
import { UserService } from 'src/app/service/user.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {
  userData:User={"id":0,"email":'',"fullName":'',"password":''};
  constructor(private userService: UserService,
    private route: ActivatedRoute, private router: Router) { }
  ngOnInit() {
    this.route.params.subscribe(
      (params) => {
        this.userService.getUser(params['id'])
        .subscribe(
          (result) => { this.userData = result; }
        )
      }
    );
  }
  edit() {
    console.log(this.userData.fullName);

    this.userService.editUser(this.userData).subscribe(
      (userData) => { this.router.navigate([''])}
    );
  }
  

}
