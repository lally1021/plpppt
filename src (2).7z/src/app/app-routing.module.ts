import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsermanagementComponent } from './components/usermanagement/usermanagement.component';
import { CreateuserComponent } from './components/createuser/createuser.component';
import { EdituserComponent } from './components/edituser/edituser.component';


const routes: Routes = [
  { path: '', component: UsermanagementComponent },
  { path: 'create', component:  CreateuserComponent },
  { path: 'edit/:id', component:  EdituserComponent},
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
