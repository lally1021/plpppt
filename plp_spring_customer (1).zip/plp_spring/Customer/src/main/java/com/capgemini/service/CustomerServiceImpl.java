package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.CustomerDao;
import com.capgemini.dto.Customer;
import com.capgemini.exception.CustomerException;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao CustomerDao;

	@Override
	public List<Customer> addCustomer(Customer customer) throws CustomerException {
		return CustomerDao.findAll();

	}

	@Override
	public List<Customer> deleteCustomer(int id) throws CustomerException {
		if (CustomerDao.existsById(id)) {
			CustomerDao.deleteById(id);
			return getAllCustomers();
		} else {
			throw new CustomerException("customer with id" + id + "does not exist");
		}
	}

	@Override
	public List<Customer> getAllCustomers() throws CustomerException {
		return CustomerDao.findAll();
	}

	@Override
	public List<Customer> editCustomer(Customer customer, int id) throws CustomerException {
		if (CustomerDao.existsById(id)) {
			CustomerDao.save(customer);
			return getAllCustomers();
		} else {
			throw new CustomerException("Invalid id. Cannot update");
		}
	}

}
