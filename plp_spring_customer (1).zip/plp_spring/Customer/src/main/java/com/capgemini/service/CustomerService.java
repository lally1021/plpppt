package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.Customer;
import com.capgemini.exception.CustomerException;

public interface CustomerService {
List<Customer>addCustomer(Customer customer) throws CustomerException;

List<Customer> deleteCustomer(int id) throws CustomerException;

List<Customer> editCustomer(Customer customer, int id) throws CustomerException;

List<Customer> getAllCustomers() throws CustomerException;

}
