package com.cg.bookstore.exception;

public class BookStoreException extends Exception{

	public BookStoreException() {
		super();
	}

	public BookStoreException(String arg0) {
		super(arg0);
	}

}
