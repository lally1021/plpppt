package com.cg.bookstore.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bookstore.bean.Book;


@Repository
public interface BookStoreDao extends JpaRepository<Book, Integer>{


}
