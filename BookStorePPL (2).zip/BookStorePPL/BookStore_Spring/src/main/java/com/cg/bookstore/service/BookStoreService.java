package com.cg.bookstore.service;

import java.util.List;

import com.cg.bookstore.bean.Book;
import com.cg.bookstore.exception.BookStoreException;

public interface BookStoreService {

	public List<Book> addBook(Book book);
	public List<Book> getAllBooks();
	public List<Book> deleteBook(int id) throws BookStoreException;
	public List<Book> editBook(Book book) throws BookStoreException;
	public Book getById(int id) throws BookStoreException;
}
