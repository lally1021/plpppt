package com.cg.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.bean.Book;
import com.cg.bookstore.exception.BookStoreException;
import com.cg.bookstore.service.BookStoreService;

@CrossOrigin("*")
@RestController
public class BookStoreController {
	@Autowired
	BookStoreService service;
	
	@PostMapping("/book")
	public List<Book> addBook(@RequestBody Book book) {
		return service.addBook(book);
	}
	@GetMapping("/books")
	public List<Book> getAllBooks(){
		return service.getAllBooks();
	}
	@DeleteMapping("/book/{id}")
	public List<Book> deleteBook(@PathVariable int id) throws BookStoreException{
	return service.deleteBook(id);
	}
	@PutMapping("/book")
	public List<Book> editBook(@RequestBody Book book) throws BookStoreException{
		return service.editBook(book);
	}
	@GetMapping("/book/{id}")
	public Book getById(@PathVariable int id) throws BookStoreException{
		return service.getById(id);
	}
}
