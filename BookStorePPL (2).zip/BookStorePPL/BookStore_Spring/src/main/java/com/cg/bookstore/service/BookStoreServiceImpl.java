package com.cg.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bookstore.bean.Book;
import com.cg.bookstore.dao.BookStoreDao;
import com.cg.bookstore.exception.BookStoreException;

@Service
public class BookStoreServiceImpl implements BookStoreService{

	@Autowired
	BookStoreDao dao;
	
	@Override
	public List<Book> addBook(Book book) {
		dao.save(book);
		return getAllBooks();
	}

	@Override
	public List<Book> getAllBooks() {
		return dao.findAll();
	}

	@Override
	public List<Book> deleteBook(int id) throws BookStoreException {
		try {
			if (dao.existsById(id)) {
				dao.deleteById(id);
				return getAllBooks();
			} else {
				throw new BookStoreException("Book with Id: " + id + " does not exists.");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());
		}
	}

	@Override
	public List<Book> editBook(Book book) throws BookStoreException {
		try {
			if (dao.existsById(book.getId())) {
				dao.save(book);
				return getAllBooks();
			} else {
				throw new BookStoreException("invalid edit");
			}
		} catch (Exception e) {

			throw new BookStoreException("invalid updation");
		}
	}

	@Override
	public Book getById(int id) throws BookStoreException {
		try {
			Optional<Book> data = dao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new BookStoreException("Book id : " + id + "does not exist.");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());
		}
	}

}
