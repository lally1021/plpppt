import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddnewbookComponent } from './book/addnewbook/addnewbook.component';
import { BooklistComponent } from './book/booklist/booklist.component';
import { EditbookComponent } from './book/editbook/editbook.component';


const routes: Routes = [ 
{ path: "", component: BooklistComponent },
{ path: "addnewbook", component: AddnewbookComponent },
{ path: "booklist", component: BooklistComponent },
{ path: "editbook/:id", component: EditbookComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
