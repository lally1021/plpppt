import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AddnewbookComponent } from './book/addnewbook/addnewbook.component';
import { BooklistComponent } from './book/booklist/booklist.component';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookService } from './service/book.service';
import { AppRoutingModule } from './app-routing.module';
import { EditbookComponent } from './book/editbook/editbook.component';

@NgModule({
  declarations: [
    AppComponent,
    AddnewbookComponent,
    BooklistComponent,
    EditbookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
