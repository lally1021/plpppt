import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shippinganddelivery',
  templateUrl: './shippinganddelivery.component.html',
  styleUrls: ['./shippinganddelivery.component.css']
})
export class ShippinganddeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
