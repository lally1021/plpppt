import { Component, OnInit } from '@angular/core';
import { Book } from '../bean/book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  books: Book[];
  constructor(private bookService: BookService) { }

  ngOnInit() {
    this.bookService.getBooks().subscribe(
      (data: Book[]) => {
      this.books = data;
        console.log("all" + this.books)
      });
  }
  delete(book: Book) {
    this.bookService.delete(book.id).subscribe(
      (data) => { this.books = this.books.filter(c => c !== book) });
  }
}
