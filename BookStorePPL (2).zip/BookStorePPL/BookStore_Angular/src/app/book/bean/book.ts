import { Category } from './category';
import { Review } from './review';

export class Book {
    id:number;
    category:Category;
    title:string;
    author:string;
    isbn:string;
    purchaseDate:Date;
    bookImage:string;
    price:number;
    description:string;
    reviews:Review[];
}