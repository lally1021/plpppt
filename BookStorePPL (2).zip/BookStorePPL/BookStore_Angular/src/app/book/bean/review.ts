export class Review {
    id:number;
    bookTitle:String;
    rating:number;
    customerName:String;
    headLine:String;
    comments:String;
    reviewDate:Date;

}