import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/service/book.service';
import { Book } from '../bean/book';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addnewbook',
  templateUrl: './addnewbook.component.html',
  styleUrls: ['./addnewbook.component.css']
})
export class AddnewbookComponent implements OnInit {

  book:Book={"id":0,
          "category":null,
        "title":'',
        "author":'',
        "isbn":'',
        "purchaseDate":null,
        "bookImage":'',
        "price":0,
        "description":'',
        "reviews":null};
   
  constructor(private bookService: BookService, private router: Router) { }

  ngOnInit() {
  }

  addBook(book: Book) {
    this.bookService.addBook(this.book).subscribe(
      (data => this.router.navigate(['booklist'])));
  }
}
