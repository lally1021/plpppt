import { Component, OnInit } from '@angular/core';
import { Book } from '../bean/book';
import { BookService } from 'src/app/service/book.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls: ['./editbook.component.css']
})
export class EditbookComponent implements OnInit {

  editedbook:Book={"id":0,
          "category":null,
        "title":'',
        "author":'',
        "isbn":'',
        "purchaseDate":null,
        "bookImage":'',
        "price":0,
        "description":'',
        "reviews":null};
        
  constructor(private bookService: BookService,private router:Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{
        this.bookService.getById(params['id'])
    .subscribe(
      (result)=>{this.editedbook=result;}
      )});

  }

  editBook(book:Book) {
    this.bookService.editBook(this.editedbook).subscribe(
      (data => {this.router.navigate(['booklist'])}));
  }
}
