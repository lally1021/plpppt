import { Injectable } from '@angular/core';
import { Book } from '../book/bean/book';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  
  url="http://localhost:3000";
  constructor(private http: HttpClient) {
  }

  addBook(book:Book) {
    return this.http.post(this.url+"/book",book);
  }
  getBooks() {
    return this.http.get<Book[]>(this.url+"/books");
  }
  delete(id:number){
    return this.http.delete<Book[]>(this.url + "/book/" + id);
  }
  editBook(book:Book){
    return this.http.put(this.url+"/book",book);
  }
  getById(id:number){
    return this.http.get<Book>(this.url+"/book/"+id);
  }
}
