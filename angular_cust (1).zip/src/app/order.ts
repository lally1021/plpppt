export class Order {
    Index:number;
    OrderId:number;
    Qunatity:number;
    TotalAmount:number;
    OrderDate:Date;
    Status:string;
    
}
