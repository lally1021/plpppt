import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { CreatecustomerComponent } from './createcustomer/createcustomer.component';
import { EditcustomerComponent } from './editcustomer/editcustomer.component';
import { RegistercustomerComponent } from './registercustomer/registercustomer.component';

import { OrderComponent } from './order/order.component';
import { CustprofileComponent } from './custprofile/custprofile.component';
import { CustmenuComponent } from './custmenu/custmenu.component';
import { CustomermanagementComponent } from './customermanagement/customermanagement.component';


const routes: Routes = [


{path:"login",component:LoginComponent},
{path:"create",component:CreatecustomerComponent},
{path:"edit",component:EditcustomerComponent},
{path:"edit/:id",component:EditcustomerComponent},
{path:"",component:RegistercustomerComponent},
{path:"profile",component:CustprofileComponent},
{path:"login/:email/:password",component:LoginComponent},
{path:"menu",component:CustmenuComponent},
{path:"order",component:OrderComponent},
{path:"customermanagement",component:CustomermanagementComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
