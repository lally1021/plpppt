import { Component, OnInit } from '@angular/core';
import { CustomerserviceService } from '../customerservice.service';
import { Customer } from '../customer';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null} 

  constructor(private customerService:CustomerserviceService,private route:Router) { }

  ngOnInit() {
  }

login()
 {
  console.log(this.customerData.email);
 this.customerData.id = this.customerService.login(this.customerData);
 console.log(this.customerData.id);
 if(this.customerData.id)
 {
 console.log(this.customerData.id);
 alert("Login Successfull");
 this.route.navigate(['profile']);
 }
 else
 {
 console.log(this.customerData.id);
 alert("Login Denied");
 }
 }



}
