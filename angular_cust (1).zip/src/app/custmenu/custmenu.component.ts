import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custmenu',
  templateUrl: './custmenu.component.html',
  styleUrls: ['./custmenu.component.css']
})
export class CustmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
