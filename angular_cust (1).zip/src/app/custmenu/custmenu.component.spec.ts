import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustmenuComponent } from './custmenu.component';

describe('CustmenuComponent', () => {
  let component: CustmenuComponent;
  let fixture: ComponentFixture<CustmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
