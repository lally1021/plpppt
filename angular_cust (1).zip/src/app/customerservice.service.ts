import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerserviceService {
  customers:Customer[];
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null} 
url:string="http://localhost:3000"
  constructor(private http:HttpClient) { }


getAllCustomers(){
  return this.http.get<Customer[]>(this.url+"/list");
}
deleteCustomer(customer:Customer){

  return this.http.delete<Customer[]>(this.url+"/"+customer.id);
}
editCustomer(customer: Customer){              
    console.log(customer);
    return this.http.put(this.url+"/edit",customer);
  }
 
createCustomer(customer: Customer){
  console.log(customer);
  customer.registerDate=new Date;
  return this.http.post<Customer>(this.url+"/create", customer);
}
getById(id:number){
  return this.http.get<Customer>(this.url+"/customer/"+id);
}
RegisterCustomer(customer:Customer){
  console.log(customer);
  return this.http.post(this.url+"/register",customer);
} 
profileCust(customer:Customer){
return this.customerData.email;

}
login (customer:Customer){
console.log(customer);
this.http.get(this.url+"/login/"+customer.email+"/"+customer.password).subscribe(
(data:Customer)=>{this.customerData=data;});
console.log(this.customerData);
return this.customerData.id;
}
}


