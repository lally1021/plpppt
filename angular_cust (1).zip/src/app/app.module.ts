import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreatecustomerComponent } from './createcustomer/createcustomer.component';
import { LoginComponent } from './login/login.component';
import { EditcustomerComponent } from './editcustomer/editcustomer.component';
import { RegistercustomerComponent } from './registercustomer/registercustomer.component';

import { OrderComponent } from './order/order.component';
import { CustprofileComponent } from './custprofile/custprofile.component';
import { CustmenuComponent } from './custmenu/custmenu.component';
import { CustomermanagementComponent } from './customermanagement/customermanagement.component';

@NgModule({
  declarations: [
    AppComponent,
    CreatecustomerComponent,
    LoginComponent,
    EditcustomerComponent,
    RegistercustomerComponent,

    OrderComponent,

    CustprofileComponent,

    CustmenuComponent,

    CustomermanagementComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
